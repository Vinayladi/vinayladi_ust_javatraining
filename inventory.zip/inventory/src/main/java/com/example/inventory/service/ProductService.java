package com.example.inventory.service;

import com.example.inventory.entity.Product;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    private final List<Product> products = new ArrayList<>();

    // ADD PRODUCT (With Assignment Validation Requirements)
    public String addProduct(Product product) {
        // 1. Validate Price
        if (product.getPrice() < 0) {
            return "Error: Price cannot be negative.";
        }
        
        // 2. Validate Quantity
        if (product.getQuantity() < 0) {
            return "Error: Quantity cannot be negative.";
        }

        // 3. Save if valid
        products.add(product);
        return "Success: Product '" + product.getName() + "' added successfully.";
    }

    // GET ALL PRODUCTS
    public List<Product> getAllProducts() {
        return products;
    }

    // UPDATE PRODUCT QUANTITY
    public String updateQuantity(int id, int newQuantity) {
        // Validate incoming update value
        if (newQuantity < 0) {
            return "Error: Updated quantity cannot be negative.";
        }

        for (Product p : products) {
            if (p.getId() == id) {
                p.setQuantity(newQuantity);
                return "Success: Product ID " + id + " quantity updated to " + newQuantity + ".";
            }
        }
        return "Error: Product ID " + id + " not found.";
    }

    // DELETE PRODUCT
    public String deleteProduct(int id) {
        boolean removed = products.removeIf(p -> p.getId() == id);
        if (removed) {
            return "Success: Product ID " + id + " has been removed.";
        }
        return "Error: Product ID " + id + " not found.";
    }
}
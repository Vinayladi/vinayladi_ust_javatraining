package com.example.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryApplication {
    public static void main(String[] args) {
        // This line kicks off the entire Spring Boot framework
        SpringApplication.run(InventoryApplication.class, args);
    }
}